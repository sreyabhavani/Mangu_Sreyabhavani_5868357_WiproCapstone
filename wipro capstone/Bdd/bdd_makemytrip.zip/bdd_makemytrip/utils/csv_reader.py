import csv

class CSVReader:
    @staticmethod
    def get_test_data(filepath):
        """
        Reads the first data row of a CSV and returns it as a dictionary.
        Assumes row 1 contains headers and row 2 contains the test data.
        """
        data = {}
        with open(filepath, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                data = row
                break # Only grabbing the first row for this test case
        return data