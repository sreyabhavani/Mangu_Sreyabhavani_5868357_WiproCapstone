import configparser
import os
from pathlib import Path


class ConfigReader:
    # Build the path relative to the root directory of your project
    # This assumes 'utils/config_reader.py' is inside your project
    _config_path = Path(__file__).parent.parent / "config" / "config.ini"

    _config = configparser.ConfigParser()

    # Read the file only once
    if _config_path.exists():
        _config.read(_config_path)
    else:
        print(f"CRITICAL: Config file not found at {_config_path}")

    @classmethod
    def get(cls, key, section="DEFAULT", fallback=None):
        """
        Safely gets a value from the config file.
        If the key doesn't exist, returns the fallback value instead of crashing.
        """
        try:
            return cls._config.get(section, key, fallback=fallback)
        except (configparser.NoOptionError, configparser.NoSectionError):
            return fallback

    @classmethod
    def get_boolean(cls, key, section="DEFAULT", fallback=False):
        try:
            return cls._config.getboolean(section, key, fallback=fallback)
        except ValueError:
            return fallback