from selenium.webdriver.common.by import By


class BookingPageLocators:
    # ------------------------------------------------------------------------
    # LOCATORS BANK (Extracted from review and checkout screens)
    # ------------------------------------------------------------------------
    FIRST_NAME_INPUT = (By.ID, "fName")
    LAST_NAME_INPUT = (By.ID, "lName")
    EMAIL_INPUT = (By.ID, "email")
    MOBILE_INPUT = (By.ID, "mNo")

    # PAN Details Field Locator
    PAN_INPUT = (By.XPATH, "//input[@placeholder='ENTER PAN HERE' or contains(@id, 'pan')] | //input[@id='panCheck']")

    # Secure Trip radio toggle
    SECURE_TRIP_YES_RADIO = (By.XPATH,
                             "//*[contains(text(), 'Yes, secure my trip')] | //label[contains(., 'secure my trip')]")

    # TARGETING: Specific class names and dynamic pay now fallbacks
    CONTINUE_PAYMENT_BUTTON = (By.XPATH,
                               "//a[contains(@class, 'btnContinuePayment')] | //a[contains(text(), 'Pay Now')]")