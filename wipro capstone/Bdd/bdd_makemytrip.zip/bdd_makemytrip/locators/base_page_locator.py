class BasePageLocators:
    """
    Global/Shared application UI locators.
    Add elements here that appear across all modules (e.g., Global Navbars, Loaders, Spinners).
    """
    pass