from selenium.webdriver.common.by import By


class HomePageLocators:
    # ------------------------------------------------------------------------
    # LOCATORS BANK (Mapped dynamically across execution screens)
    # ------------------------------------------------------------------------
    LANDING_CONTAINER = (By.XPATH, "//div[@data-cy='landingContainer']")
    HOTELS_MODULE = (By.XPATH, "//li[@data-cy='menu_Hotels']")

    CITY_TAP_CONTAINER = (By.XPATH, "//span[@data-cy='hotelCityLabel']")
    CITY_INPUT_FIELD = (By.XPATH, "//input[@placeholder='Where do you want to stay?']")
    FIRST_SUGGESTION = (By.XPATH,
                        "//ul[contains(@class,'react-autosuggest__suggestions-list')]/li[1] | //div[contains(@class,'autosuggest')]//li[1] | //p[contains(@class,'suggestion')][1]")

    CHECKIN_DATE_27 = (By.XPATH,
                       "//div[contains(@aria-label,'May 27 2026')] | //div[@class='DayPicker-Day' and .//p[text()='27']]")
    CHECKOUT_DATE_30 = (By.XPATH,
                        "//div[contains(@aria-label,'May 30 2026')] | //div[@class='DayPicker-Day' and .//p[text()='30']]")

    GUESTS_APPLY_BUTTON = (By.XPATH,
                           "//button[@data-cy='doneBtn'] | //button[contains(@class, 'btnApplyPersons')] | //button[text()='APPLY']")
    HOTELS_SEARCH_BUTTON = (By.XPATH,
                            "//button[@data-cy='submit'] | //button[@id='hsw_search_button'] | //button[contains(@class, 'widgetSearchBtn')]")

    FLEXIBLE_STAY_MODAL = (By.XPATH,
                           "//div[contains(@class, 'trueFlexiModal')] | //div[@id='portal-root']//div[contains(@class, 'modalContainer')]")
    MODAL_SKIP_BUTTON = (By.XPATH,
                         "//span[text()='SKIP'] | //span[contains(@class, 'text') and text()='SKIP'] | //div[contains(@class, 'trueFlexiModal')]//span[contains(text(), 'SKIP')]")

    # Dynamic filter paths mapping 5-Star checkboxes across multiple viewport resolutions
    FIVE_STAR_FILTER = (By.XPATH,
                        "//span[@data-testid='checkboxFilter' and contains(., '5 Star')] | //label[contains(., '5 Star')]//span[contains(@class, 'check')] | //li[contains(., '5 Star')]//input[@type='checkbox']")
    FIRST_HOTEL_CARD = (By.XPATH,
                        "(//div[@id='hotelListingContainer']//div[contains(@class, 'ListingCard')]//a)[1] | (//div[contains(@id, 'ListingCard')]//h9)[1] | (//div[contains(@class, 'ListingCard')])[1]")