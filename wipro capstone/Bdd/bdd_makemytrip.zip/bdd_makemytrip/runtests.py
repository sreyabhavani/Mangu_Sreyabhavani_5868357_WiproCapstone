import os
import shutil
from datetime import datetime
from utils.logger import AutomationLogger

logger = AutomationLogger.get_logger("TestRunner")

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
logger.info("==========================================================================")
logger.info(f"MAKEMYTRIP NATIVE BEHAVE AUTOMATION WORKFLOW INITIATED: {timestamp}")
logger.info("==========================================================================")

os.makedirs("reports", exist_ok=True)

# Purge stale artifact caches
if os.path.exists("reports/allure-results"):
    logger.info("Clearing historical allure-results telemetry...")
    shutil.rmtree("reports/allure-results")

if os.path.exists("reports/allure-report"):
    logger.info("Purging historical compiled html dashboards...")
    shutil.rmtree("reports/allure-report")

# Run native Behave validation
logger.info("Invoking native Behave execution loop pipeline...")
behave_status = os.system("behave -f allure_behave.formatter:AllureFormatter -o reports/allure-results")
logger.info(f"Behave engine execution completed with exit code: {behave_status}")

# Generate visual Allure charts
logger.info("Compiling high-performance visual dashboards...")
allure_generate_status = os.system(
    r"C:\allure\allure-2.30.0\bin\allure.bat generate reports/allure-results -o reports/allure-report --clean"
)
logger.info(f"Allure static compiler reports generation exit code: {allure_generate_status}")
logger.info("==========================================================================")