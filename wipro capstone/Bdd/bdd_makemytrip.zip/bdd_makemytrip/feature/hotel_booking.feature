Feature: MakeMyTrip Hotel Booking Workspace Functionality

  Background: Core Application Initialisation
    Given User launches the MakeMyTrip application storefront
    And The system automatically handles or bypasses initial authentication pop-up overlays

  @hotel @search
  Scenario: Search hotels for destination from test data
    When User selects the Hotels workspace module panel
    And User inputs destination parameters, calendar stay dates, and applies guest specifications
    Then Hotel search results should be dynamically displayed in the viewport grid

  @hotel @filter
  Scenario: Apply 5 Star classification filter on hotel results
    When User selects the Hotels workspace module panel
    And User inputs destination parameters, calendar stay dates, and applies guest specifications
    And User dismisses any promotional flexible stay overlay windows if present
    And User applies the standard "5 Star" rating quality filter option
    Then Search results should refresh to display only premium verified listings

  @hotel @booking
  Scenario: Enter guest details and PAN metrics on review booking page
    When User selects the Hotels workspace module panel
    And User inputs destination parameters, calendar stay dates, and applies guest specifications
    And User applies the standard "5 Star" rating quality filter option
    And User selects the primary premium choice hotel card from the listings grid
    And User switches to the hotel profile workspace tab and clicks the "BOOK THIS NOW" button
    And User inputs traveler demographic information and matching PAN card details from the CSV dataset
    Then Guest details fields and validation states should update with CSV parameters

  @hotel @payment
  Scenario: Progress past review page onto final gateway via secure trip confirmation
    When User selects the Hotels workspace module panel
    And User inputs destination parameters, calendar stay dates, and applies guest specifications
    And User applies the standard "5 Star" rating quality filter option
    And User selects the primary premium choice hotel card from the listings grid
    And User switches to the hotel profile workspace tab and clicks the "BOOK THIS NOW" button
    And User inputs traveler demographic information and matching PAN card details from the CSV dataset
    And User handles the secure trip insurance option and clicks the "PAY NOW" action button
    Then The automation workflow should successfully transition onto the final payment gateway screen

  @hotel @guestdetails @negative
  Scenario: Intercept workflow validation failure during missing customer parameters
    When User selects the Hotels workspace module panel
    And User inputs destination parameters, calendar stay dates, and applies guest specifications
    And User applies the standard "5 Star" rating quality filter option
    And User selects the primary premium choice hotel card from the listings grid
    And User switches to the hotel profile workspace tab and clicks the "BOOK THIS NOW" button
    And User inputs an empty layout dataset containing missing customer info parameters
    And User handles the secure trip insurance option and clicks the "PAY NOW" action button
    Then The application should flag form inline errors and prevent payment gateway redirection

  @hotel @guestdetails @negative
  Scenario: Validate mandatory input boundaries remain clean under blank data entry
    When User selects the Hotels workspace module panel
    And User inputs destination parameters, calendar stay dates, and applies guest specifications
    And User applies the standard "5 Star" rating quality filter option
    And User selects the primary premium choice hotel card from the listings grid
    And User switches to the hotel profile workspace tab and clicks the "BOOK THIS NOW" button
    And User inputs an empty layout dataset containing missing customer info parameters
    Then Primary traveler input fields should remain empty and highlight mandatory field requirements