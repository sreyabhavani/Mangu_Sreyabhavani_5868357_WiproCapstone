Feature: MakeMyTrip Hotel Booking Automation
from behave import given, when, then

  Scenario: Search and verify booking flow for a 5-star hotel using CSV data
    Given User launches MakeMyTrip application
    And User loads hotel test data from CSV "test_data.csv"
    When User closes the login popup
    And User navigates to the Hotels section
    And User enters destination city from CSV
    And User selects check-in and check-out dates
    And User clicks on Search Hotels button
    And User applies the 5 Star filter
    And User selects the first available hotel
    And User clicks on Book This Now
    And User enters guest details from CSV
    And User proceeds to final payment
    Then Close the browser