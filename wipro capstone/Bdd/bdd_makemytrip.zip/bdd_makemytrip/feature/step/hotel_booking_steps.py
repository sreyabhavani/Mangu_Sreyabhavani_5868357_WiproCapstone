import os
import allure
from behave import given, when, then
from pages.home_page import HomePage
from pages.hotel_details_page import HotelDetailsPage
from pages.booking_page import BookingPage
from utils.logger import AutomationLogger
from utils.screenshot_util import ScreenshotUtil

# 1. Changed import to your CSV reader
from utils.csv_reader import CSVReader

logger = AutomationLogger.get_logger()

@given(u'User launches MakeMyTrip application')
def step_impl(context):
    logger.info("Application Launched via environment.py")

# 2. Updated step description to CSV
@given(u'User loads hotel test data from CSV "{filename}"')
def step_impl(context, filename):
    filepath = os.path.join(os.getcwd(), "testdata", filename)
    # 3. Updated class call to CSVReader
    context.test_data = CSVReader.get_test_data(filepath)
    logger.info(f"Test data loaded from {filename}")

@when(u'User closes the login popup')
def step_impl(context):
    HomePage(context.driver).close_popup()

@when(u'User navigates to the Hotels section')
def step_impl(context):
    HomePage(context.driver).select_hotels_tab()

# 4. Updated step description
@when(u'User enters destination city from CSV')
def step_impl(context):
    city = context.test_data.get("city")
    HomePage(context.driver).select_hotel_city(city)

@when(u'User selects check-in and check-out dates')
def step_impl(context):
    HomePage(context.driver).select_dates()

@when(u'User clicks on Search Hotels button')
def step_impl(context):
    HomePage(context.driver).click_search()

@when(u'User applies the 5 Star filter')
def step_impl(context):
    HotelDetailsPage(context.driver).filter_five_star_hotels()
    logger.info("Applied 5-star rating filter")

@when(u'User selects the first available hotel')
def step_impl(context):
    HotelDetailsPage(context.driver).select_first_hotel()

@when(u'User clicks on Book This Now')
def step_impl(context):
    HotelDetailsPage(context.driver).click_book_now()

# 5. Updated step description
@when(u'User enters guest details from CSV')
def step_impl(context):
    booking_page = BookingPage(context.driver)

    name = context.test_data.get("guest_name")
    email = context.test_data.get("email")
    mobile = context.test_data.get("mobile")
    pan = context.test_data.get("pan_number")

    booking_page.fill_guest_details(name, email, mobile)
    booking_page.fill_pan_details(pan)
    ScreenshotUtil.capture_screenshot(context.driver, "hotel_guest_details")

@when(u'User proceeds to final payment')
def step_impl(context):
    BookingPage(context.driver).click_pay_now()
    ScreenshotUtil.capture_screenshot(context.driver, "payment_screen")

@then(u'Close the browser')
def step_impl(context):
    logger.info("End of Hotel E2E Flow. Browser will close via environment.py")